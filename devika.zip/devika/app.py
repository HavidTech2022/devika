# Streamlit main app placeholder

import streamlit as st
st.title('Smart Attendance System')
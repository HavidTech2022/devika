# Smart Real-Time Attendance System

This repository contains the source code, documentation, and dataset structure for the Smart Real-Time Attendance System using face recognition.

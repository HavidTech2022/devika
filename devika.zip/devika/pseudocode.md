## Pseudocode for Attendance Tracking

1. Start camera stream
2. Detect face using Haarcascade
3. Recognize face using InsightFace
4. If face is known:
    - Log attendance
    - Update CSV and Redis
5. Else:
    - Flag as UNKNOWN
    - Trigger alert
## Source Code 
     import numpy as np 
     import pandas as pd 
     import cv2
import redis 
import time
from datetime 
import datetime
from insightface.app import FaceAnalysis 
from sklearn.metrics import pairwise
from streamlit_webrtc import webrtc_streamer 
import av
import time


# Connect to the Redis Database
hostname = 'redis-15190.c283.us-east-1-4.ec2.redns.redis-cloud.com' portnumber = 15190
password = 'fuFvBUyP4Qq6Qx6ZIii8SV2VY3fQQr3b'


r = redis.StrictRedis( host = hostname, port = portnumber, password = password)
# Retrieve Data from database def retrive_data(name):
retrive_dict = r.hgetall(name) retrive_series = pd.Series(retrive_dict)
retrive_series = retrive_series.apply(lambda x: np.frombuffer(x,dtype=np.float32))
index = retrive_series.index
index = list(map(lambda x: x.decode(), index)) retrive_series.index = index
retrieve_df = retrive_series.to_frame().reset_index()
 
retrieve_df.columns = ['Name_Matricnum', 'Facial_Features'] retrieve_df[['Name','Matricnum']] =
retrieve_df['Name_Matricnum'].apply(lambda x: x.split('- ')).apply(pd.Series)
return retrieve_df[['Name', 'Matricnum', 'Facial_Features']] class RealTimePred:
def   init  (self):
self.logs = dict(name=[], matricnum=[],current_time=[])


def reset_dict(self):
self.logs = dict(name=[], matricnum=[],current_time=[])


def saveLogs_redis(self):
# step-1: create a logs dataframe dataframe = pd.DataFrame(self.logs)

# step-2: drop the duplicate information (we will take only one distinct name)
dataframe.drop_duplicates('name', inplace=True)


# step-3: push the data to the redis database #encode the data
name_list = dataframe['name'].tolist() matricnum_list = dataframe['matricnum'].tolist() ctime_list = dataframe['current_time'].tolist() global encoded_data
encoded_data = []
for name, matricnum, ctime in zip(name_list,matricnum_list,ctime_list):
if name != 'UNKNOWN':
concat_string = f"{name}@{matricnum}@{ctime}" encoded_data.append(concat_string)
 
if len(encoded_data) > 0: r.lpush('attendance:logs',*encoded_data)



self.reset_dict()


def face_prediction(self,test_image,dataframe,feature_column,name_matric num=['Name','Matric Number'],thresh=0.5):
#step-0: find the time current_time = str(datetime.now())

# step-1: take the test image and apply to insightface results = faceapp.get(test_image)
test_copy = test_image.copy()


# step-2: use a for loop to extract each embedding and pass it to the ml search algoorithm
for res in results:
x1, y1, x2, y2 = res['bbox'].astype(int) embeddings = res['embedding']
person_name, matricnum = ml_search_algorithm(dataframe,
feature_colu
 
mn,


embeddings,


um=name_matricnum,


h)
if person_name == 'UNKNOWN': color = (0,0,255)
else:
 


test_vector=


name_matricn


thresh=thres
 
color = (0,255,0)


cv2.rectangle(test_copy, (x1,y1), (x2,y2),color) text_gen = person_name cv2.putText(test_copy,text_gen,(x1,y1),cv2.FONT_HERSHEY_
DUPLEX,0.7,color,2)
cv2.putText(test_copy,current_time,(x1,y2+10),cv2.FONT_H ERSHEY_DUPLEX,0.7,color,2)
# save the name, matricnum and time in the logs dict self.logs['name'].append(person_name) self.logs['matricnum'].append(matricnum) self.logs['current_time'].append(current_time)

return test_copy


Appendix 2: Model Initialization
# Configure FaceAnalysis
faceapp = FaceAnalysis(name='buffalo_l',
root='insightface model', providers=['CPUExecutionProvider'])
faceapp.prepare(ctx_id=0, det_size=(640,640), det_thresh=0.5)


# ML search ALgorithm def
ml_search_algorithm(dataframe,feature_column,test_vector,name_matric num=['Name','Matric Number'],thresh=0.5):
"""
Cosine Similarity Base Search Algorithm """
# step-1: take the dataframe (collection of the data) dataframe = dataframe.copy()
 
# step-2: index face embedding from the dataframe and convert it into an array
X_list = dataframe[feature_column].tolist() x = np.asarray(X_list)

 



1))
 
# step-3: calculate the cosine similarity
simialar = pairwise.cosine_similarity(x,test_vector.reshape(1,-


simialar_arr = np.array(simialar).flatten() dataframe['cosine'] = simialar_arr
 

# step-4: filter the data
data_filter = dataframe.query(f'cosine >= {thresh}') if len(data_filter) > 0:
# step-5: get the person name data_filter.reset_index(drop=True,inplace=True) argmax = data_filter['cosine'].argmax()
person_name,	person_role	= data_filter.loc[argmax][name_matricnum]

else:
person_name = 'UNKNOWN' person_role = 'UNKNOWN'

return person_name, person_role
Appendix 3: Interface st.set_page_config(page_title='Predictions') st.subheader('Real-Time Attendance System')


#  Retrive the data from Redis Database
with st.spinner('Retrieving Data from Redis Database...'): redis_face_db = face_rec.retrive_data(name ='student:data')
 
# st.dataframe(redis_face_db)
st.success('Data Successfully retrived from Database')


#time to take to store the data waitTime = 30
setTime = time.time()
realtimepred = face_rec.RealTimePred()


# call back function
def video_frame_callback(frame): global setTime
img = frame.to_ndarray(format="bgr24") #3d numpy array


# operations that can be performed on the array pred_img =
realtimepred.face_prediction(img,redis_face_db,'Facial_Features',['N ame','Matricnum'],thresh=0.5)

timenow = time.time() difftime = timenow - setTime if difftime >= waitTime:
realtimepred.saveLogs_redis setTime = time.time()
print('Save Data to Redis Database')


return av.VideoFrame.from_ndarray(pred_img, format="bgr24")




webrtc_streamer(key="realtimePrediction",video_frame_callback=video_ frame_callback)
 
st.set_page_config(page_title='Registratrion Form') st.subheader('Registration Form')

# step-1: Collect the person name and matric number using a form name = st.text_input(label='Name', placeholder='Enter Full Name') role = st.selectbox(label='Select your Role', options=('Staff','Student'))
if role == 'Student':
matric_num = (st.text_input(label='Matriculation Number', placeholder='Enter Matriculation Number'))
else:
staff_id = (st.text_input(label='Staff ID', placeholder='Enter Staff ID'))


upload_folder = os.path.join(os.getcwd(), "images")
uploaded_image = st.file_uploader("Upload an image...", type=["png", "jpg", "jpeg"])

if st.button('Submit'):
if uploaded_image is not None: if role == 'Student':
# Generate a unique file name using name and matric
number
file_name = f"{name}-{matric_num}.jpg"  # Save as .jpg
or original extension
file_path = os.path.join(upload_folder, file_name) with open(file_path, "wb") as f:
f.write(uploaded_image.getbuffer())
else:
# Generate a unique file name using name and staff id file_name2 = f"{name}-{staff_id}.jpg" # Save as .jpg or
original extension
 
file_path2 = os.path.join(upload_folder, file_name2) with open(file_path2, "wb") as f:
f.write(uploaded_image.getbuffer()) st.success("Image saved")


#if st.button('Submit'): person_info = []
list_dir = os.listdir(path = 'images') for img_name in list_dir:
name, matric_num = (img_name.split('-'))


# path of each image in the folder (images) for file in list_dir:
path = f'images/{img_name}' # step 1: read the image img_arr = cv2.imread(path)

# step 2: get the info
result = face_rec.faceapp.get(img_arr, max_num = 1)


if len(result) > 0:
# step 3: extract facial embedding res = result[0]
embedding = res['embedding']
# step 4: save all info name, matric_number and embedding in a list
person_info.append([name,matric_num,embedding]) dataframe = pd.DataFrame(person_info, columns =
['Name','Matric Number','Facial_Features']) #st.dataframe(dataframe)
 

database
 
# Preparing the facial data for storing in the redis


xvalues = dataframe.values
col_name = np.array(dataframe.columns) np.savez('student_dataframe_values.npz', xvalues,col_name) np_file =
 
np.load('student_dataframe_values.npz',allow_pickle=True) xvalues = np_file['arr_0']
col_name = np_file['arr_1']
df = pd.DataFrame(xvalues,columns=col_name)


df['name_matricnumber'] = df['Name']+'-'+df['Matric Number'] records =
df[['name_matricnumber','Facial_Features']].to_dict(orient='records'
)


for record in records:
name_matricnumber = record['name_matricnumber'] vector = record['Facial_Features']

#convert numpy array into bytes vector_bytes = vector.tobytes()

#save data into the redis cloud face_rec.r.hset(name='student:data',key=name_matricnumbe
r,value=vector_bytes) #st.success("Image saved")


name = 'attendance:logs' def load_logs(name,end=-1):
logs_list = face_rec.r.lrange(name,start=0,end=end) # this will extract all the data from the redis database
return logs_list
 
# tabs to show theinfo
tab1,tab2, tab3 = st.tabs(['Registered Data', 'Attendance Logs','Alert Page'])

with tab1:
if st.button('Refresh Data'):
with st.spinner('Retrieving Data from Redis Database...'): redis_face_db = face_rec.retrive_data(name
='student:data')
st.dataframe(redis_face_db[['Name','Matricnum']])


with tab2:
if st.button('Refresh Logs'): st.write(load_logs(name=name))
